/*
 * Zeta Producer Online-CMS
 * http://www.zeta-producer.com
*/

var _dataDomain = null;
var _sessionId = null;
var _currentArticleId = null;

function InitCms( dataDomain,  
				  sessionId,
				  showLoginDialog)
{
	_dataDomain = dataDomain;
	_sessionId = sessionId;
	
	InitTinyMce();
	InitImageUploadEvent();
	InitFileUploadEvent();
	
	if ( showLoginDialog )
	{
		OpenLoginDialog();		
	}
}

function InitTinyMce()
{		
	$z("#dialog-edit-article").dialog({
		modal: true,
		autoOpen: false,
		height: 580,
		width: 750,
		zIndex: 7000	
	});
	
	$z("#zpocmstext").tinymce({ 
		script_url : '<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/cms/etc/tiny_mce/tiny_mce.js', 
		
		mode : "textareas", 
        theme : "advanced",
        skin : "thebigreason",
        language : "de",
        plugins : "spellchecker,lists,advhr,insertdatetime,table,tableDropdown,advimage,advlink,contextmenu,inlinepopups",
        dialog_type : "modal",
        init_instance_callback : "setTabIndexOfButtons",
 
        theme_advanced_buttons1 : "paste,|,undo,|,bold,italic,underline,|,justifyleft,justifycenter,justifyright,|,bullist,numlist,|,outdent,indent,|,forecolor,backcolor,|,formatselect,fontsizeselect,removeformat,|,link,zpuploadimage,zpuploadfile,tableDropdown,|,code", 
        theme_advanced_buttons2 : "",       
        theme_advanced_buttons3 : "",
        theme_advanced_toolbar_location : "top", 
        theme_advanced_toolbar_align : "left", 
        theme_advanced_statusbar_location : "none",
        theme_advanced_resizing : true,

		//content_css : "<?php echo $this->_['Configuration']['siteUrl'];?>/assets/styles.css",

    	setup : function(ed) 
    	{  
            ed.addButton('zpuploadimage', 
            { 
                title : 'Bild einfügen', 
                image : '<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/cms/etc/_inline-editing/image_add.png', 
                onclick : function() 
                {  
                    ed.focus();
                    uploadInsertImage( _currentArticleId );
                } 
            }); 
            ed.addButton('zpuploadfile', 
            { 
                title : 'Datei einfügen', 
                image : '<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/cms/etc/_inline-editing/file_add.png', 
                onclick : function() 
                {  
                    ed.focus();
                    uploadInsertFile( _currentArticleId );
                } 
            }); 
    	}			
	});
}

function InitImageUploadEvent()
{
	$z("#imageFile1").change(function() {
		$z(".zp-dialog-upload-image .ui-dialog-title").text('Upload...');
		$z("#dialog-upload-image-chooser").hide();
		$z(".zp-dialog-upload-image .ui-dialog-buttonpane").css('visibility', 'hidden');

	    $z(this).upload("<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/cms/cms.inc.php", 
	    		{
    				"async": "true",
    				"dataDomain" : _dataDomain,
    	    		"PHPSESSID" : _sessionId,
    	    		"view": "uploadFile",
					"action": "uploadImageAttachment",
					"articleId": _currentArticleId,
					"attachmentType": "image"
	    		},
			    function(data) 
			    {	
	    			var arrData = data.split(":::");

					if( arrData.length <= 1  )
					{
						alert("Fehler bei der Datenübertragung.\n" + data);
						return;
					}

					var status = arrData[0];
					var info = arrData[1];

					if( status == "OK")
					{
						var html = "";

						if( arrData.length <= 2 ) 
						{
							// Zu klein und/oder keine Fancybox gewünscht.
							html = "<img src='" + info + "'>";
						}
						else
						{
							// Fancybox.

							var largeUrl = arrData[2];

							var rndId = new Date().getTime();

							html = 
								"<div id='igal" + rndId + "' class='zpImageGallery' data-kind='singleimage' " + 
									"data-transition='elastic' " +
									">" +
									"<a class='fancybox' href='" + largeUrl + "'>" +
										"<img src='" + info + "'>" +
									"</a>" +
								"</div>";
						}

		        		$z("#zpocmstext").tinymce().execCommand( 'mceInsertRawHTML', true, html );
									            
		        		$z("#dialog-upload-image").dialog("close");
					}
					else
					{
						$z(".zp-dialog-upload-image .ui-dialog-title").text('Bild einfügen');
						$z("#dialog-upload-image-chooser").show();
						$z(".zp-dialog-upload-image .ui-dialog-buttonpane").css('visibility', 'visible');

						$z("#dialog-upload-image-message").html( data );		
					}
					
	    		}, "html");
	});
}

function InitFileUploadEvent()
{
	$z("#fileFile1").change(function() {
		$z(".zp-dialog-upload-file .ui-dialog-title").text('Upload...');
		$z("#dialog-upload-file-chooser").hide();
		$z(".zp-dialog-upload-file .ui-dialog-buttonpane").css('visibility', 'hidden');
		
	    $z(this).upload("<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/cms/cms.inc.php", 
	    		{
    				"async": "true",
    				"dataDomain" : _dataDomain,
    	    		"PHPSESSID" : _sessionId,
    	    		"view": "uploadFile",
					"action": "uploadFileAttachment",
					"articleId": _currentArticleId,
					"attachmentType": "file"
	    		},
			    function(data) 
			    {	
	    			var arrData = data.split(":::");

					if( arrData.length <= 1  )
					{
						alert("Fehler bei der Datenübertragung.\n" + data);
						return;
					}

					var status = arrData[0];
					var info = arrData[1];

					if( status == "OK")
					{
		        		$z("#zpocmstext").tinymce().execCommand(
							'mceInsertRawHTML', 
							true, 
							"<a href='" + info + "' target='_blank'>Datei downloaden</a>");
									            
		        		$z("#dialog-upload-file").dialog("close");
					}
					else
					{
						$z(".zp-dialog-upload-file .ui-dialog-title").text('Datei einfügen');
						$z("#dialog-upload-file-chooser").show();
						$z(".zp-dialog-upload-file .ui-dialog-buttonpane").css('visibility', 'visible');

						$z("#dialog-upload-file-message").html( data );		
					}
					
	    		}, "html");
	});
}

function setTabIndexOfButtons()
{
	$z("#zpocmstext_toolbar1 *").attr("tabIndex", "-1");
}
					
function OpenLoginDialog()
{
	$z("#login-form").dialog("open");
}

$z(function() 
{
	function loginError( t ) 
	{
		// Schütteln, weil falsch.
		$z('#login-form').parent().effect("shake", {times: 3}, 80, function() {$z("#password").focus();});
	}
	
	$z("#login-form").dialog({
		zIndex: 7000,
		dialogClass: "zp-login-form",
		autoOpen: false,
		height: 160,
		width: 280,
		modal: true,
		hide: "fade",
		show: "fade",
		draggable: false,
		resizable: false,
		buttons: {
			"Anmelden": function() {
				$z(".zp-login-form input").prop('disabled', 'true');
				$z(".zp-login-form button").prop('disabled', 'true');
			
				$z.get("<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/cms/cms.inc.php",
						{
							view: "editPage",
							action: "login",
							password: $z("#password").val(),
							dataDomain: _dataDomain,
							PHPSESSID: _sessionId
						},
						function(data)
						{
							$z(".zp-login-form input").removeProp('disabled');
							$z(".zp-login-form button").removeProp('disabled');

							if ( data == "ok") 
							{
								$z(".zp-login-form .ui-dialog-title").text('Laden...');
								$z(".zp-login-form .ui-dialog-buttonpane").css('visibility', 'hidden');
								$z(".zp-login-form #login-input-area").css('visibility', 'hidden');

								$z.get("<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/cms/cms.inc.php",
									{
										view: "editPage",
										dataDomain: _dataDomain,
										async: "true",
										PHPSESSID: _sessionId
									},
									function(data)
									{
										setTimeout(function() 
										{
											$z("#cms_content").html( data ).fadeTo();
											$z("#login-form").dialog("close");
										}, 2000 )
									}
								);													
							}
							else
							{
								loginError( data );
							}
						}
					);
			},
			"Abbrechen": function() {
				$z(this ).dialog("close");
			}
		},
		close: function() {
			$z("#login-input-area").fadeIn();
			$z("#password").val("").removeClass("ui-state-error");
		}
	});

	$z('#login-form').live('keyup', function(e){   if (e.keyCode == 13) { $z(':button:contains("Anmelden")').click(); } }); 
});

function reportEditArticleError( t ) 
{
	$z("#validateTipsEdit").text( t );
	$z("#validateTipsEdit").addClass("ui-state-highlight");
	$z("#validateTipsEdit").show();
	
	setTimeout(function() 
	{
		$z("#validateTipsEdit").removeClass("ui-state-highlight", 1500 );
	}, 500 );
	setTimeout(function() 
	{
		$z("#validateTipsEdit").fadeOut();
	}, 5000 );
}

function retrieveDataAsync( articleId, callback )
{				
	$z.get("<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/cms/cms.inc.php",
			{
				view: "dataRequest",
				action: "dataRequest",
				articleId: articleId,
				dataDomain: _dataDomain,
				async: "true",
				PHPSESSID: _sessionId
			},
			function(data)
			{	
				callback( data );
			}
	);
} 

function retrieveDataSync( articleId )
{
	 var result = null;      
	 var scriptUrl = "<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/cms/cms.inc.php";      
	 $z.ajax(
	 {
		 url: scriptUrl,
		 type: 'get',
		 dataType: 'html',
		 async: false,
		 data:
		 {
			view: "dataRequest",
			action: "dataRequest",
			articleId: articleId,
			dataDomain: _dataDomain,
			async: "true",
			PHPSESSID: _sessionId
		 },
		 success: function(data) 
		 {
			 result = data;
		 }
	 });
	 
	 return result;
}

function setArticleData( articleData )
{
	var arrData = articleData.split(";;;");
	var heading = $z("#zpocmsheading");
	var text = $z("#zpocmstext");
	
	if( arrData.length <= 1  )
	{
		alert("Fehler bei der Datenübertragung.\n" + articleData);
		return;
	}

	heading.val( arrData[0] );
	text.html( arrData[1] );
}

function editArticle(articleId, insertAt)
{
	var heading = "";
	var text = "";
	
	if( articleId != 0 )
	{
		retrieveDataAsync( articleId, setArticleData  );	
	}
	
	_currentArticleId = articleId;

	showEditArticleDialog( articleId, insertAt, heading, text);
}

function storeArticle( articleId, 
					   insertAt, 
					   sHeading, 
					   sText )
{
	var result = null;      
	var scriptUrl = "<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/cms/cms.inc.php";
	
	 $z.ajax(
	 {
		 url: scriptUrl,
		 type: 'post',
		 dataType: 'html',
		 async: false,
		 data:
		 {
			 view: "dataRequest",
			action: "storeArticle",
			async: "true",
			articleId: articleId,
			insertAtArticleId: insertAt,
			Heading: sHeading,
			Text: sText,
			dataDomain: _dataDomain,
			PHPSESSID: _sessionId
		 },
		 success: function(data) 
		 {
			 result = data;
		 }
	 });
	 
	 return result;
}

function updateContentAsync( request )
{
	$z("#cms_content").load("<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/cms/cms.inc.php?async=true&dataDomain="  + _dataDomain + "&PHPSESSID=" + _sessionId + "&" + request );
}

function updateArticlesAsync( request )
{
	$z("#articles").load("<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/cms/cms.inc.php?view=articles&async=true&dataDomain=" + _dataDomain + "&PHPSESSID=" + _sessionId + "&" + request);
}

function showEditArticleDialog( articleId, insertAt, sHeading, sText )
{		
	var heading = $z("#zpocmsheading");
	var text = $z("#zpocmstext");
	var	tips = $z("#validateTipsEdit");

	heading.val( sHeading );	
	text.html( sText );
													
	$z("#dialog-edit-article").dialog(
	{
		zIndex: 7000,
		autoOpen: true,
		dialogClass: "dialog-edit-article",
		resizable: true,
		height: 580,
		width: 770,
		modal: true,
		hide: "fade",
		show: "fade",
		buttons: {
			"OK": function() {
				text.removeClass("ui-state-error");

				if( text.val().length == 0)
				{
					text.addClass("ui-state-error");
					reportEditArticleError ("Bitte geben Sie einen Artikeltext ein.");
					return;
				}
				
				tips.text("Artikel wird gespeichert...");

				data = storeArticle( _currentArticleId, 
									 insertAt, 
									 heading.val(), 
									 text.val() );

				if ( is_int( data ) && 
					 data > 0) 
				{			
					$z.get("<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/cms/cms.inc.php",
						{
							view: "articles",
							dataDomain: _dataDomain,
							async: "true",
							PHPSESSID: _sessionId
						},
						function(data)
						{		
							$z("#articles").html( data ).fadeTo();
						
							setTimeout( function() 
							{
								$z("#dialog-edit-article").dialog("close");
								tips.text("");
							}, 500 );	
						}
					);													
				}
				else
				{
					reportEditArticleError( data );
				}
			},
			"Abbrechen": function() {
				$z(this ).dialog("close");
			}
		},
		open: function(event, ui)
		{
			tips.hide();
			window.onbeforeunload = function(){ return 'Alle Änderungen gehen verloren.'; }
			heading.css('color', '#000000');
			
			// Style the buttons and set the OK Button to the width of the cancel button
			var buttons = $z(event.target).parent().find('.ui-dialog-buttonset').children();
			 $z(buttons[0]).css('width',$z(buttons[1]).width())
								
			heading.focus( function() 
			{				
		        if(this.value == this.defaultValue) 
			    {
		            this.value = "";
		            $z(this).css('color', '#000000');

			    } 
		    }); 
			
			heading.blur( function() 
			{
		        if( this.value == "")
		        {
		            this.value = this.defaultValue;
		            $z(this).css('color', '#666');
		        }
		    });
			
			//text.tinymce().focus(); 
		},
		close: function() 
		{
			window.onbeforeunload = null;
			//$z("#zpocmstext").tinymce().destroy();
			//$z("#dialog-edit-article").dialog("destroy");
		}
	});
}

function uploadInsertImage( articleId )
{	
	$z("#imageFile1").val("");
	$z("#dialog-upload-image-chooser").show();
	$z("#dialog-upload-image-message").html("");
	
	if ( articleId == null ||
		 articleId == 0 )
	{
		var heading = $z("#zpocmsheading").val();
		var text = $z("#zpocmstext").val();
		
		if( text == "")
		{
			text = "<p></p>";
		}
		
		data = storeArticle( 0, 0, heading, text );
		
		if( is_int( data ))
		{
			_currentArticleId = data;
		}
	}
	
	$z("#dialog-upload-image").dialog(
	{	
		dialogClass: "zp-dialog-upload-image",
		zIndex: 7000,
		width: 320,
		height: 140,
		resizable: false,
		draggable: false,
		modal: true,
		hide: "fade",
		show: "fade",
        buttons: 
	    {
            "Abbrechen": function()
            {
            	$z(this ).dialog("close");
            }
        },
		open: function(event, ui)
		{
			$z("#imageFile1").click();
		}
    });
}

function uploadInsertFile( articleId )
{	
	$z("#fileFile1").val("");
	$z("#dialog-upload-file-chooser").show();
	$z("#dialog-upload-file-message").html("");
	
	if ( articleId == null ||
		 articleId == 0 )
	{
		var heading = $z("#zpocmsheading").val();
		var text = $z("#zpocmstext").val();
		
		if( text == "")
		{
			text = "<p></p>";
		}
		
		data = storeArticle( 0, 0, heading, text );
		
		if( is_int( data ))
		{
			_currentArticleId = data;
		}
	}
	
	$z("#dialog-upload-file").dialog(
	{	
		dialogClass: "zp-dialog-upload-file",
		zIndex: 7000,
		width: 320,
		height: 140,
		resizable: false,
		draggable: false,
		modal: true,
		hide: "fade",
		show: "fade",
        buttons: 
	    {
            "Abbrechen": function()
            {
            	$z(this ).dialog("close");
            }
        },
		open: function(event, ui)
		{
			$z("#fileFile1").click();
		}
    });
}

function deleteArticle( id, name )
{
	document.getElementById('dialog-confirm-deletion-text').innerHTML = "Wollen Sie den Artikel \"" + name + "\" wirklich löschen?";
	
	$z("#dialog-confirm-deletion").dialog("destroy");
	
	$z(function() {
		$z("#dialog-confirm-deletion").dialog({
			zIndex: 7000,
			resizable: false,
			height:160,
			width:300,
			modal: true,
			hide: "fade",
			show: "fade",
			buttons: {
				"OK": function() {
					$z(this ).dialog("close");
					
					updateArticlesAsync("action=deleteArticle&articleId=" + id);
				},
				"Abbrechen": function() {
					$z(this ).dialog("close");
				}
			}
		});
	});
}

function is_int(value){ 
	  if((parseFloat(value) == parseInt(value)) && !isNaN(value)){
	       return true;
	   } else { 
	      return false;
	   } 
	}