<?php
class Configuration 
{
	public static $CMS_VERSION = '1.01';
	public static $CMS_DATE = '05.10.2010';
	public static $CMS_DATASTORAGEDIR = 'CMS_DATA';
	public static $CMS_DATASTORAGEPATH_WEB = '/assets/php/CMS_DATA';
	public static $CMS_MAXUPLOADSIZE = 5242880;
	
	public static function getCmsDataStoragePath()
	{
		return dirname(realpath(__FILE__)) . "/../" . Configuration ::$CMS_DATASTORAGEDIR;
	}
	
	public static function getCmsDataStoragePathWeb()
	{
		return Configuration::$CMS_DATASTORAGEPATH_WEB;
	}
}
?>