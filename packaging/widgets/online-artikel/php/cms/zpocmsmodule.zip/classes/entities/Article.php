<?php
/**
 * Class Article
 *
 * A article object.
 */

include_once 'Entity.php';

class Article extends Entity
{
	private $heading;
	private $text;
	private $orderPosition;
	private $advancedData;
		
	/**
	* Constructor
	*/
	function Article( $model ) 
	{	
		parent::Entity( $model );
		
		$this->advancedData = new AdvancedArticleData();
	}
	
	public function Load( $row )
	{
		parent::Load( $row );
									  
		$this->heading = $row['Heading'];
		$this->text = $row['Text'];
		$this->orderPosition = $row['OrderPosition'];
		
		if( array_key_exists( "AdvancedData", $row ))
		{
			$this->advancedData = unserialize( base64_decode( $row['AdvancedData'] ));
		}
	}
	
	public function StoreRow( &$row )
	{
		parent::StoreRow( $row );
		
		$row['Heading'] = $this->heading;
		$row['Text'] = $this->text;
		$row['OrderPosition'] = $this->orderPosition;
		$row['AdvancedData'] = base64_encode( serialize( $this->advancedData ));
	}
	
	public function Store()
	{	
		$row = array();
				
		$this->StoreRow( $row );
			
		return $this->model->getDataLink()->StoreObject( $row );
	}
	
	public function Delete()
	{
		//echo "Deleting Item $this->id - $this->text";
		$this->RemoveAllAssets();
		return $this->model->DeleteArticleById( $this->id );
	}
	
	public function AddAsset( $asset )
	{
		$assets = $this->advancedData->getAssets();
		$assets[] = $asset;
		
		$this->advancedData->setAssets($assets);
			
		$this->Store();
	}
	
	public function RemoveAsset( $asset )
	{
		$assets = $this->advancedData->getAssets();
		
		foreach ($assets as $key => $currAsset) 
		{
			if( $currAsset->getFileName() == $asset->getFileName() )
			{
				unset($assets[$key]);

				$assetsNew = array_values($assets);
				$this->advancedData->setAssets( $assetsNew );				
			}	
		}
		
		$asset->Delete();
		$this->Store();
	}
	
	public function RemoveAllAssets()
	{
		$assets = $this->advancedData->getAssets();
		
		if( $assets == null )
		{
			return;
		}
		
		foreach ($assets as $currAsset) 
		{
			$this->RemoveAsset( $currAsset );	
		}
	}
	
	public function DoCheckForUnusedAssetsAndRemove()
	{
		$assets = $this->advancedData->getAssets();
				
		if( $assets == null )
		{
			return;
		}
				
		foreach ( $assets as $key => $currAsset ) 
		{
			$searchAsset = $currAsset->getFilename();
			$result = stristr ( $this->getText(), $searchAsset );
			
			if( $result == false )
			{
				$this->RemoveAsset( $currAsset );
			}
		}	
	}
	
	static function cmp_Position($a, $b)
    {
        $al = strtolower( $a->getOrderPosition() );
        $bl = strtolower( $b->getOrderPosition() );
        if ( $al == $bl ) {
            return 0;
        }
        return ( $al > $bl ) ? +1 : -1;
    }
	
	
	/**
	 * @return the $heading
	 */
	public function getHeading() {
		return $this->heading;
	}

	/**
	 * @return the $text
	 */
	public function getText() {
		return $this->text;
	}
	
	public function getOrderPosition() {
		return $this->orderPosition;
	}
	
	public function getAdvancedData() {
		return $this->advancedData;
	}

	/**
	 * @param field_type $heading
	 */
	public function setHeading($heading) {
		$this->heading = $heading;
	}

	/**
	 * @param field_type $text
	 */
	public function setText($text) {
		$this->text = $text;
	}
	
	public function setOrderPosition( $position ) {
		$this->orderPosition = $position;
	}
}

class AdvancedArticleData
{
	private $assets;
	
	public function getAssets()
	{
		return $this->assets;
	}
	
	public function setAssets( $assets )
	{
		$this->assets = $assets; 
	}
} 
?>