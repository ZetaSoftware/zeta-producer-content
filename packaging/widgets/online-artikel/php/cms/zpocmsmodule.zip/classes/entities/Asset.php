<?php
/**
 * Class Asset
 *
 * An article asset object.
 * 
 */

include_once 'Entity.php';

class Asset extends Entity
{
	private $type;
	private $originalFileName;
	private $fileName;
	private $largeFileName;
	
	public function Asset( $model )
	{
		parent::Entity( $model );
		
		$this->model = $model;
	}
		
	public function Delete()
	{
		$path = $this->model->getDataLink()->getDataStoragePathAssets() . "/" . $this->fileName;
		
		if ( is_file( $path ) )
		{
			unlink( $path );	
		}	

		if( !isNullOrEmptyString($this->largeFileName))
		{
			$path = $this->model->getDataLink()->getDataStoragePathAssets() . "/" . $this->largeFileName;
			
			if ( is_file( $path ) )
			{
				unlink( $path );	
			}	
		}
	}
	
	public function Store()
	{
	}
	
	public static function CreateImageAssetFromUploadedFile( $model, $uploadFileInfo )
	{
		global $zoomImageOnClick;
		global $scaleImagesIfWiderThan;
		global $gdSupportedMimeTypes;
		$gdSupportedMimeTypes = array();
		
		// check GD-Support of various filetypes and keep a list of supported mime types
		if ( function_exists("gd_info") ) {
			$gdinfo = gd_info();
			if ( $gdinfo["JPEG Support"] ){
				array_push($gdSupportedMimeTypes, "image/jpeg");
				array_push($gdSupportedMimeTypes, "image/pjpeg");
			}
			if ( $gdinfo["PNG Support"] ){
				array_push($gdSupportedMimeTypes, "image/png");
			}
			if ( $gdinfo["GIF Create Support"] ){
				array_push($gdSupportedMimeTypes, "image/gif");
			}
		}
		
		// check if the mime-type of the current file would be supported by GD
		$gdSupportsCurrentFile = false;
		if ( in_array(strtolower($uploadFileInfo['type']), $gdSupportedMimeTypes) ){
			$gdSupportsCurrentFile = true;
		}

		// --

		$clickZoom = isset($zoomImageOnClick) ? $zoomImageOnClick : true;
		$maxWidth = isset($scaleImagesIfWiderThan) && $scaleImagesIfWiderThan > 0 ? $scaleImagesIfWiderThan : 1200;

		// --

		$asset = null;
		
		$originalName = $uploadFileInfo['name'];
		$tmpFileName = $uploadFileInfo['tmp_name'];
		
		$fileName = uniqid() . "." . getExtension( $originalName );
		$fullNewPath = $model->getDataLink()->getDataStoragePathAssets() . $fileName;
		
		if ( move_uploaded_file( $tmpFileName, $fullNewPath) ) 
		{
			$asset = new Asset( $model );
			
			$asset->setType( "image" );
			$asset->setFilename( $fileName );
			$asset->setOriginalFilename( $originalName );

			$uploadFileInfo["tmp_name"] = $fullNewPath;
			$uploadFileInfo["name"] = $fileName;
			
			require_once dirname(__FILE__) . "/../business/Photo.php";
			
			$errors = array();
			$photo = new Photo( $uploadFileInfo );
						  
			if( $gdSupportsCurrentFile && $photo->getWidth() > $maxWidth ) 
			{  
				if ( $clickZoom )
				{
					// Benutzer soll Bild anklicken können und mit FancyBox zoomen.
					// Brauche zweite Version des Bildes.

					$largeFileName = getFileNameWidthoutExtension($fileName) . "-large." . getExtension( $fileName );
					$largeFullNewPath = $model->getDataLink()->getDataStoragePathAssets() . $largeFileName;

					$asset->setLargeFilename( $largeFileName );

					// Kopieren der Datei.
					$errors = copy($fullNewPath, $largeFullNewPath);
				}

				// Bild verkleinern. 
				$errors = $photo->doResize( $maxWidth, $model->getDataLink()->getDataStoragePathAssets() );  
			}
			
			if ( count ( $errors ) >= 1 )
			{
				$asset = null;
			}
		} 
		
		return $asset;
	} 
		
	public static function CreateFileAssetFromUploadedFile( $model, $uploadFileInfo )
	{
		$asset = null;
		
		$originalName = $uploadFileInfo['name'];
		$tmpFileName = $uploadFileInfo['tmp_name'];
		
		$fileName = uniqid() . "." . getExtension( $originalName );
		$fullNewPath = $model->getDataLink()->getDataStoragePathAssets() . $fileName;
		
		if ( move_uploaded_file( $tmpFileName, $fullNewPath) ) 
		{
			$asset = new Asset( $model );
			
			$asset->setType( "file" );
			$asset->setFilename( $fileName );
			$asset->setOriginalFilename( $originalName );

			$uploadFileInfo["tmp_name"] = $fullNewPath;
			$uploadFileInfo["name"] = $fileName;
		} 
		
		return $asset;
	} 
		
	public function getType() {
		return $this->id;
	}
	
	public function getOriginalFilename() {
		return $this->originalFileName;
	}
	
	public function getFilename() {
		return $this->fileName;
	}

	public function getLargeFilename() {
		return $this->largeFileName;
	}
	
	public function setType( $type ) {
		$this->type = $type;
	}
	
	public function setOriginalFilename( $originalName ) {
		$this->originalFileName = $originalName;
	}
	
	public function setFilename( $fileName ) {
		$this->fileName = $fileName;
	}
	
	public function setLargeFilename( $largeFileName ) {
		$this->largeFileName = $largeFileName;
	}
}
?>
