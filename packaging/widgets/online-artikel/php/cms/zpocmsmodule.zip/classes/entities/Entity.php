<?php
/**
 * Class Entity
 *
 * Base class for entities. 
 */
abstract class Entity
{
	protected $model;
	protected $id = 0;
	
	public function Entity( $model )
	{
		$this->model = $model;
	}
	
	public function Load( $row )
	{
		$this->id = $row['ID'];
	}
	
	public function StoreRow( &$row )
	{
		$row['ID'] = $this->id;
	}
	
	abstract public function Store();
	abstract public function Delete();
	
	
	/**
	 * @return the $model
	 */
	public function getModel() {
		return $this->model;
	}
	/**
	 * @return the $id
	 */
	public function getId() {
		return $this->id;
	}

	/**
	 * @param field_type $id
	 */
	public function setId($id) {
		$this->id = $id;
	}


}
?>