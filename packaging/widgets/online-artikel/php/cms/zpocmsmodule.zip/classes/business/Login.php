<?php
/**
 * Class Login
 *
 * Manages login taks
 */

Class Login
{   
	private $masterController = null;   
	
	/**  
	 * Contructor
	 *  
	 * @param Array $request Array of $_GET & $_POST.  
	 */  
	public function Login(
		$masterController)
	{   
		$this->masterController = $masterController;
	}

	/**
	* Checks if view / action requires login.
	* If yes, checks if user is logged in.
	* If not logged in stops execution.
	*/
	public function DoCheckLoginRequired()
	{
		$proceed = false;
		
		if( $this->masterController->getAction() != null )
		{
			switch ( $this->masterController->getAction() )
			{
				case 'storeArticle':
				case 'deleteArticle':
				case 'uploadImageAttachment':
				case 'uploadFileAttachment':
				case 'logout':
					if( $this->getIsLoggedIn() )
					{
						$proceed = true;
					}
					break;	
					
				case 'login':
					// No login required
					$proceed = true;
					break;
				
				default:
					$proceed = false;
			}
		}
		
		// If not valid for now check the views requirements.
		if ( !$proceed )
		{
			switch( $this->masterController->getView() )
			{   
				case 'dataRequest':
					if( $this->getIsLoggedIn() )
					{
						$proceed = true;
					}
					break;
				case 'editPage':
				case 'articles':
				case 'displayPage':
					// No login required
					$proceed = true;	
					break;
					
				default:
					$proceed = false;
					break;		
			}
		}
		
		if ( !$proceed )
		{
			die("Nicht angemeldet.");
		}
	}
	
	public function getIsLoggedIn()
	{
		if ( isset( $_SESSION[$this->masterController->getDataDomain() . '_isLoggedIn'] ))
		{
			return true;
		}
		return false;
	}
	
	/**
	* Checks the login data of a user.
	*
	* @param Array Request
	* @param View
	*/
	public function LoginUser(
		$request,
		$view)
	{
		$pagePassword = $this->getPagePassword();
		
		if($request["password"] == $pagePassword)
		{
			$_SESSION[$this->masterController->getDataDomain() . '_isLoggedIn'] = true;
			echo "ok"; 
		}
		else
		{
			echo "Das angegebene Kennwort ist nicht korrekt. Bitte versuchen Sie es erneut.";
		}
	}
	
	public function LogoutUser(
		$request,
		$view)
	{
		unset( $_SESSION[$this->masterController->getDataDomain() . '_isLoggedIn'] );
	}
	
	/**
	* Gets the set page password out of the session.
	* If not set tries to get out of the producer generated page that includes the cms. 
	*/
	public function getPagePassword()
	{		
		if ( isset( $_SESSION[$this->masterController->getDataDomain() . "_pagePassword"] ) )
		{
			return $_SESSION[$this->masterController->getDataDomain() . "_pagePassword"];
		}
		if ( isset( $GLOBALS["editPagePassword"]) )
		{
			$_SESSION[$this->masterController->getDataDomain() . "_pagePassword"] = $GLOBALS["editPagePassword"];
			return $GLOBALS["editPagePassword"];
		}
	}
}
?>