<?php
/**
 * Class Model
 *
 * Provides data access.
 */

require_once('entities/Article.php');
require_once('entities/Asset.php');
require_once('DataLink.php');

class Model{

	private $dataLink = null;
	private $dataDomain;
	
	public function Model( $dataDomain )
	{
		$this->dataLink = new DataLink(
									Configuration::getCmsDataStoragePath(), 
									$dataDomain );
			
		$this->dataLink->Connect();
	}
	
	/**  
	 * Returns all articles in the database
	 *  
	 * @return Array Array Article 
	 */  
	public function GetAllArticles()
	{   		
		$result = $this->dataLink->ReadAllObjects();
		
		if ( $result != null )
		{
			// http://de2.php.net/array_multisort - code-snippet array_msort
			//$result = array_msort( $result, array( 'OrderPosition'=>array(SORT_ASC, SORT_NUMERIC )));
			//$result = array_orderby($result, 'OrderPosition', SORT_ASC);
						
			$articles = array();
			$index = 0;
			
			foreach ($result as $row) 
			{  	
				$article = new Article( $this );
				$article->Load( $row );
								  
				$articles[$index] = $article;
	
				$index++;
			}
						
			unset($result);
			
			usort( $articles , array( "Article", "cmp_Position" ));
					
			return $articles;
		}
		
		return null;
	}

	/**  
	 * Returns a article by a given id.
	 *  
	 * @param int $id 
	 * @return Article Article The article. If not found returns null.
	 */
	public function GetArticleById(
		$id)
	{		
		
		$row = $this->dataLink->ReadObject( $id );
		$article = new Article( $this );
		
		if ( $row != null )
		{
			$article->Load( $row );
		}							  
			
		return $article; 
	}
	
	/**  
	 * Returns a article by a order position
	 *  
	 * @param int $orderPos 
	 * @return Article Article The article. If not found returns null.
	 */
	public function GetArticleByOrderPosition(
		$orderPos)
	{	
		foreach ( $this->GetAllArticles() as $article) {
			if( $article->getOrderPosition() == $orderPos )
			{
				return $article;	
			}
		}							  
			
		return null; 
	}
	
	public function GetLastArticleOrderPosition()
	{
		return $this->dataLink->getStorageInfo()->getLastOrderPosition();
	}
		
	/**
	* Removes a article from the database by id.
	* 
	* @param $id
	*/
	public function DeleteArticleById(
		$id)
	{	
		return $this->dataLink->DeleteObject( $id );
	}
	
	/**
	 * Ensures that all articles have correct order positions.
	 */
	public function EnsureArticleOrderPositionsSet()
	{
		$lastPos = $this->ReorderArticleOrderPositions( 1 );
		
		$this->dataLink->getStorageInfo()->setLastOrderPosition( $lastPos );		
	}
	
	/**
	 * Reorders the article positions.
	 * @return the last order position set
	 */
	function ReorderArticleOrderPositions( $from )
	{
		$articles = $this->GetAllArticles();
		$index = $from;
		
		if ( $articles == null )
		{
			return;
		}
		
		foreach ($articles as $article) 
		{	
			$currPos = $article->getOrderPosition();
			
			if ( $currPos >= $index ||
				 empty( $currPos ) ||
				 $from == 1 )
			{				
				$article->setOrderPosition( $index );
				$article->Store();
				
				$index++;	
			}
		}
		
		return $index - 1; 
	}
	
	/**
	 * Shifts up the order positions to make space.
	 * @param $shiftUpBy # to shift up
	 * @param $fromPos
	 */
	function ShiftArticleOrderPositionsBy( $shiftUpBy, $fromPos )
	{
		$articles = $this->GetAllArticles();
		
		if ( $articles == null )
		{
			return;
		}
				
		foreach ($articles as $article) 
		{	
			$currPos = $article->getOrderPosition();
			
			if ( $currPos >= $fromPos )
			{				
				$article->setOrderPosition( $currPos + $shiftUpBy );
				$article->Store();	
			}
		}
	}
	
	/**
	* Moves an article up or down.
	* 
	* @param $article The article to move.
	* @param $posChange up oder down, + or - X.
	*/
	function MoveArticle(
		$article,
		$posChange )
	{
		$this->EnsureArticleOrderPositionsSet();
		
		$corresponding = $this->GetArticleByOrderPosition( $article->getOrderPosition() + $posChange );

		if ( $corresponding != null )
		{
			$article->setOrderPosition( $article->getOrderPosition() + $posChange );
			
			if( $posChange < 0 )
			{
				$corresponding->setOrderPosition( $corresponding->getOrderPosition() + 1 );
			}
			else
			{
				$corresponding->setOrderPosition( $corresponding->getOrderPosition() - 1 );
			}
			
			$corresponding->Store();
			
			$article->Store();
			$this->ReorderArticleOrderPositions( $article->getOrderPosition() );
		}
	}
			
	/**
	 * @return the $dataLink
	 */
	public function getDataLink() 
	{
		return $this->dataLink;
	}
}   
?>