<?php
$articles = $this->_['articles'];
$isEditMode = $this->_['isEditMode'];
$isLoggedIn = $this->_['isLoggedIn'];
$dataDomain = $this->_['dataDomain'];
$siteUrl =  $this->_['Configuration']['siteUrl'];
?>

<div id="articles">
<?php 
	$viewArticles = new View();
	$viewArticles->SetTemplate('articles');
			
	$viewArticles->Assign('articles', $articles);
	$viewArticles->Assign('isEditMode', $isEditMode);
	$viewArticles->Assign('isLoggedIn', $isLoggedIn);

	echo $viewArticles->LoadTemplate();
?>
</div>

<p></p>
<?php
if ( $isEditMode && $isLoggedIn)
{ 
?>
	<input type="button" id="btnInsertArticle" onClick="javascript:editArticle(0,0); return false;" value="Neuen Artikel einfügen"/>
	<input type="button" id="btnLogout" onClick="javascript:window.location = '?action=logout'; return false;" value="Abmelden"/>
	<script>
		$z( "#btnInsertArticle" ).button();
		$z( "#btnLogout" ).button();
	</script>
<?php
}
else 
{
	
	if ( $isLoggedIn )
	{
?>
		<input type="button" id="btnEditPage" onClick="javascript:updateContentAsync('view=editPage'); return false;" value="Seite bearbeiten"/>
		<input type="button" id="btnLogout" onClick="javascript:window.location = '?action=logout'; return false;" value="Abmelden"/>
		<script>
			$z( "#btnEditPage" ).button();
			$z( "#btnLogout" ).button();
		</script>
<?php
	}
}
?>