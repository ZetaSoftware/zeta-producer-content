<?php
	echo $this->_['content'];
?>