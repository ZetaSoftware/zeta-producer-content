/*
 * Zeta Producer Protected Area
 * http://www.zetaproducer.com
 * 
 * @author  Daniel Friedrich
 * @version 1.0 11.11.2011
 * @copyright (c)2011 Zeta Software GmbH
*/

var _homeUrl = null;
var _sessionId = null;

function InitPa( sessionId,
			   	 homeUrl)
{
	_sessionId = sessionId;
	_homeUrl = homeUrl;
}

function ShowLoginDialog()
{
	$( "#login-form" ).dialog( "open" );
}

$( function() 
		{
			var pagePassword = $( "#password" );
			var	tips = $( "#validateTips" );
			var valid= false;

			function loginError( t ) 
			{
				tips.text( t );
				tips.addClass( "ui-state-highlight" );
				pagePassword.addClass( "ui-state-error" );
				setTimeout(function() 
				{
					tips.removeClass( "ui-state-highlight", 1500 );
				}, 500 );
			}
			
			$( "#login-form" ).dialog({
				autoOpen: false,
				height: 240,
				width: 280,
				modal: true,
				resizable: false,
				hide: "fade",
				show: "fade",
				buttons: {
					"Anmelden": function() {
						pagePassword.removeClass( "ui-state-error" );
					
						$.get( window.location.href,
								{
									action: "login",
									password: pagePassword.val(),
									PHPSESSID: _sessionId
								},
								function(data)
								{
									if ( data == "ok" ) 
									{
										$( "#login-input-area" ).fadeOut();
										setTimeout(function() 
										{
											tips.text( "Zugang gewährt, die Seite wird geladen..." );
										}, 250 )
										
										setTimeout(function() 
										{
											$( "#login-form" ).dialog( "close" );
										}, 500 )
										
										valid = true;
									}
									else
									{
										loginError( data );
									}
								}
							);
					},
					"Abbrechen": function() {
						$( this ).dialog( "close" );
					}
				},
				close: function() {
					if ( valid )
					{
						location.reload(true);
					}
					else
					{
						window.location = _homeUrl ;
						//$( "body" ).load( _homeUrl ).fadeTo();
					}
				}
			});

			$('#login-form').live('keyup', function(e){   if (e.keyCode == 13) {     $(':button:contains("Anmelden")').click();   } }); 
				
		});