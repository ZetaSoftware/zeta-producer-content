<?php
	$areaName = $this->_['areaName'];
	$areaTitle = $this->_['areaTitle'];
	$siteUrl = $this->_['siteUrl'];
	
	if ( empty( $areaName ) || 
		 preg_match('/^[a-f0-9]{32}$/',$areaName))
	{ 
		$description = "Der Zugriff auf diese Seite ist eingeschränkt.";
		//$description = "Der Zugriff auf die Seite '" . substr( strrchr( parse_url( $_SERVER["REQUEST_URI"], PHP_URL_PATH ), "/"), 1 ) . "' ist eingeschränkt."; 
	}
	else 
	{
		$description = "Der Zugriff auf den Bereich '" . $areaName . "' ist eingeschränkt.";
	}
	
	if ( empty( $areaTitle ))
	{
		$title = "Anmelden";
	}
	else
	{
		$title = $areaTitle;	
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>Geschützter Bereich - Anmelden</title>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link type="text/css" href="<?php echo $this->_['siteUrl']?>/assets/php/pa/etc/jquery/theme/jquery-ui-1.8.11.custom.css" rel="Stylesheet" />	
	<script type="text/javascript" src="<?php echo $this->_['siteUrl']?>/assets/php/pa/etc/jquery/jquery-1.7.min.js"></script>
	<script type="text/javascript" src="<?php echo $this->_['siteUrl']?>/assets/php/pa/etc/jquery/jquery-ui-1.8.16.custom.min.js"></script>
	<script type="text/javascript" src="<?php echo $this->_['siteUrl']?>/assets/php/pa/etc/zpprotectedarea.js" ></script>
	
	<style type="text/css" >
		input.text { margin-bottom:5px; padding: 5px; font-size:1.25em;}
		fieldset { padding:0; border:0; margin-top:20px; }
		label { padding-right:5px; }
		validateTips { border: 1px solid transparent; padding: 5px; }
		.ui-dialog .ui-state-error { padding: 5px;; }
	</style>
</head>
<body>
	<script type="text/javascript">
	<!--
		$(function() 
		{
			// test if a URL exists and only then call "callback" function
			function urlExists(url, callback){
			  $.ajax({
				type: 'GET',
				global: false,
				processData: false,
				url: url,
				success: function(){
				  callback(url);
				}
			  });
			}
			// insert a full page background via an iFrame if url exists
			function loadIframe(url){
				$("body").append('<iframe id="backgroundframe" src="' + url + '" style="width: 100%; height: 100%; position: absolute; top: 0; left: 0; overflow: hidden; border: 0; z-index: -1;" seamless />');
			}
			// load background iframe if current page is not the same as the Startpage (siteURL)
			var currentNonStartUrl = window.location.href.replace(/(index\.php|index\.html|\/)$/, "");
			var siteUrlNonStart = "<?php echo $this->_['siteUrl']?>".replace(/(index\.php|index\.html|\/)$/, "");
			if ( currentNonStartUrl !== siteUrlNonStart ){
				urlExists("<?php echo $this->_['siteUrl']?>/", loadIframe);
			}
			
			InitPa( "<?php echo( session_id() ); ?>", "<?php echo( $siteUrl ); ?>" )
			ShowLoginDialog();
		});	
	//-->
	</script>

	<div id="login-form" title="<?php echo( $title ); ?>" style="display:none;">
		<p id="validateTips"><?php echo( $description ); ?></p>
		<div id="login-input-area">
		<fieldset>
			<label for="password">Kennwort:</label>
			<input type="password" name="password" id="password" value="" class="text ui-widget-content ui-corner-all" style="width:235px" />
		</fieldset>
		</div>
	</div>
</body>
</html>