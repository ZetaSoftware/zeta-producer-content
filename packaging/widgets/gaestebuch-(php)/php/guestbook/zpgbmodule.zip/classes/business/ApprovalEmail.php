<?php
/**
 * Class ApprovalEmail
 *
 * Represents an email to approve a guestbook entry
 * 
 * @author  Daniel Friedrich
 * @version 1.0 05.12.2011
 * @copyright (c)2011 zeta Software GmbH
 */

require_once('mailer/PHPMailerAutoload.php');

Class ApprovalEmail
{   
	private $masterController = null;
	private $entry;   
	
	/**  
	 * Contructor
	 *  
	 * @param Controller  
	 * @param Entry The corresponding entry.
	 */  
	public function ApprovalEmail(
		$masterController,
		$entry)
	{   
		$this->masterController = $masterController;
		$this->entry = $entry;
	}
	
	private function createBody()
	{
		$creatorEmail = $this->entry->getEmail();
		$creatorHomepage = $this->entry->getHomepage();
		//$pageFileName = substr( strrchr( parse_url( $this->masterController->getPageUrl(), PHP_URL_PATH ), "/"), 1 );
		
		$body[] = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html xmlns=\"http://www.w3.org/1999/xhtml\">";
	    $body[] = "<head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /><title></title><style type=\"text/css\">body { font-family: Verdana, Helvetica, sans-serif; font-size: 12px; } h1 {font-size:14px;}</style></head><body>";
	    $body[] = "<h1>Auf Ihrer Website wurde ein neuer Gästebucheintrag erfasst</h1>";
	    $body[] = "<p>Bitte überprüfen Sie nachfolgende Eingaben und entscheiden Sie ob der Eintrag veröffentlicht werden soll.</p>";
	    $body[] = "<p>";
	    $body[] = "Name: " .  $this->entry->getName() . "<br/>";
	    
		if ( !empty( $creatorEmail )) 
	    {
	    	$body[] = "Email: " . $this->entry->getEmail() . "<br/>"; 
	    }
	    if ( !empty( $creatorHomepage )) 
	    {
	    	$body[] = "Website: " . $this->entry->getHomepage() . "<br/>"; 
	    } 
	    
	    $body[] = "Kommentar: " . nl2br( $this->entry->getText() );
		
	    $body[] = "</p><p><a href=\"" . $this->masterController->getPageUrl() . "?action=approveEntry&entryId=" . $this->entry->getId() . "&otp=" . $this->masterController->getApprovalKey( $this->entry ) . "&dataDomain=" . $this->masterController->getDataDomain() . "\">Eintrag veröffentlichen</a>&nbsp;|&nbsp;<a href=\"" . $this->masterController->getPageUrl() . "?action=deleteEntry&entryId=" . $this->entry->getId() . "&otp=" . $this->masterController->getApprovalKey( $this->entry ) . "&dataDomain=" . $this->masterController->getDataDomain() . "\">Eintrag löschen</a></p>";
		$body[] = "<br/>";
		$body[] = "<hr/>";
		$body[] = "<p style=\"font-size:10px; color:grey;\">Besucher-IP-Adresse: " . $this->entry->getIp() . "<br/>";
		$body[] = "Besucher-Hostname: " . gethostbyaddr( $this->entry->getIp() ) . "<br/>";
	    $body[] = "</body></html>";
	    
	    $bodyStr = implode( "\r\n", $body );
	    
	    return $bodyStr;
	}
	
	public function Send()
	{
		$receiverEmail = $this->masterController->getNotificationEmail();
				
		$senderEmail = $this->masterController->getNotificationEmail();
		$senderName = "Gästebuch";
		
		$subject = "Neuer Gästebucheintrag auf " . $this->masterController->getPageUrl(); 
		$body = $this->createBody();
			




		// Passing true to the constructor enables the use of exceptions for error handling.
		$mail = new PHPMailer(true);

		$mail->setLanguage('de', 'language');
		$mail->CharSet = 'utf-8';

		$mail->isHTML(true); 
		$mail->From      = $senderEmail;
		$mail->FromName  = $senderName;
		$mail->Subject   = $subject;
		$mail->Body      = $body;
		$mail->addAddress( $receiverEmail );
		$mail->addReplyTo( $senderEmail, $senderName );

		$mail->Send();

		return true;





		/*
		$header = array();
		$header[] = "From: " . $senderName . " <" . $senderEmail . ">";
		$header[] = "MIME-Version: 1.0";
		$header[] = "Content-Type: text/html; charset=UTF-8";
			
	    if( mail( $receiverEmail, 
		      	   mb_mime_header($subject, "utf-8"), 
		    	   $this->createBody(),
		    	   implode( PHP_EOL, $header )))
		{
			return true;	   	  	
		}
		else 
		{
			return false;
		}
		*/
	}
}
?>