<?php
/**
 * Class Model
 *
 * Provides data access.
 * 
 * @author  Daniel Friedrich
 * @version 1.0 30.11.2010
 * @copyright (c)2011 zeta Software GmbH
 */

require_once('entities/Entry.php');
require_once('DataLink.php');

class Model
{

	private $dataLink = null;
	private $dataDomain;
	
	public function Model( $dataDomain )
	{
		$this->dataLink = new DataLink(
									Configuration::getGuestboookDataStoragePath(), 
									$dataDomain );
			
		$this->dataLink->Connect();
	}
	
	/**  
	 * Returns all entries in the database
	 *  
	 * @return Array Array Entry 
	 */  
	public function GetAllEntries()
	{   		
		$result = $this->dataLink->ReadAllObjects();
		
		if ( $result != null )
		{
			// http://de2.php.net/array_multisort - code-snippet array_msort
			//$result = array_msort( $result, array( 'OrderPosition'=>array(SORT_ASC, SORT_NUMERIC )));
			//$result = array_orderby($result, 'OrderPosition', SORT_ASC);
						
			$entries = array();
			$index = 0;
			
			foreach ($result as $row) 
			{  	
				$entry = new Entry( $this );
				$entry->Load( $row );
								  
				$entries[$index] = $entry;
	
				$index++;
			}
						
			unset($result);
			
			usort( $entries , array( "Entry", "cmp_Position" ));
					
			return $entries;
		}
		
		return null;
	}

	/**  
	 * Returns a entry by a given id.
	 *  
	 * @param int $id 
	 * @return Entry Entry The entry. If not found returns null.
	 */
	public function GetEntryById(
		$id)
	{		
		
		$row = $this->dataLink->ReadObject( $id );
		$entry = new Entry( $this );
		
		if ( $row != null )
		{
			$entry->Load( $row );
		}							  
			
		return $entry; 
	}
	
	/**  
	 * Returns a entry by a order position
	 *  
	 * @param int $orderPos 
	 * @return Entry Entry The entry. If not found returns null.
	 */
	public function GetEntryByOrderPosition(
		$orderPos)
	{	
		foreach ( $this->GetAllEntries() as $entry) {
			if( $entry->getOrderPosition() == $orderPos )
			{
				return $entry;	
			}
		}							  
			
		return null; 
	}
	
	public function GetLastEntryOrderPosition()
	{
		return $this->dataLink->getStorageInfo()->getLastOrderPosition();
	}
		
	/**
	* Removes a entry from the database by id.
	* 
	* @param $id
	*/
	public function DeleteEntryById(
		$id)
	{	
		return $this->dataLink->DeleteObject( $id );
	}
	
	/**
	 * Ensures that all entries have correct order positions.
	 */
	public function EnsureEntryOrderPositionsSet()
	{
		$lastPos = $this->ReorderEntryOrderPositions( 1 );
		
		$this->dataLink->getStorageInfo()->setLastOrderPosition( $lastPos );		
	}
	
	/**
	 * Reorders the entry positions.
	 * @return the last order position set
	 */
	function ReorderEntryOrderPositions( $from )
	{
		$entries = $this->GetAllEntries();
		$index = $from;
		
		if ( $entries == null )
		{
			return;
		}
		
		foreach ($entries as $entry) 
		{	
			$currPos = $entry->getOrderPosition();
			
			if ( $currPos >= $index ||
				 empty( $currPos ) ||
				 $from == 1 )
			{				
				$entry->setOrderPosition( $index );
				$entry->Store();
				
				$index++;	
			}
		}
		
		return $index - 1; 
	}
	
	/**
	 * Shifts up the order positions to make space.
	 * @param $shiftUpBy # to shift up
	 * @param $fromPos
	 */
	function ShiftEntryOrderPositionsBy( $shiftUpBy, $fromPos )
	{
		$entries = $this->GetAllEntries();
		
		if ( $entries == null )
		{
			return;
		}
				
		foreach ($entries as $entry) 
		{	
			$currPos = $entry->getOrderPosition();
			
			if ( $currPos >= $fromPos )
			{				
				$entry->setOrderPosition( $currPos + $shiftUpBy );
				$entry->Store();	
			}
		}
	}
	
	/**
	* Moves an entry up or down.
	* 
	* @param $entry The entry to move.
	* @param $posChange up oder down, + or - X.
	*/
	function MoveEntry(
		$entry,
		$posChange )
	{
		$this->EnsureEntryOrderPositionsSet();
		
		$corresponding = $this->GetEntryByOrderPosition( $entry->getOrderPosition() + $posChange );

		if ( $corresponding != null )
		{
			$entry->setOrderPosition( $entry->getOrderPosition() + $posChange );
			
			if( $posChange < 0 )
			{
				$corresponding->setOrderPosition( $corresponding->getOrderPosition() + 1 );
			}
			else
			{
				$corresponding->setOrderPosition( $corresponding->getOrderPosition() - 1 );
			}
			
			$corresponding->Store();
			
			$entry->Store();
			$this->ReorderEntryOrderPositions( $entry->getOrderPosition() );
		}
	}
			
	/**
	 * @return the $dataLink
	 */
	public function getDataLink() 
	{
		return $this->dataLink;
	}
}   
?>