<?php
/**
 * Class Controller
 *
 * Controlles the inclusion of the Online-CMS frontend.
 * 
 * @author  Daniel Friedrich
 * @version 1.6 04.10.2011
 * @copyright (c)2011 zeta Software GmbH
 */

require_once('business/Login.php');
require_once('business/ApprovalEmail.php');

class Controller
{   
	private $request = null;   
	private $action = null;   
	private $template = '';
	private $view = null;
	private $model = null;
	private $isAsyncCall = false;
	private $loginController = null;

	/**  
	 * Contructor
	 *  
	 * @param Array $request Array of $_GET & $_POST.  
	 */  
	public function Controller(
		$request)
	{   
		$this->doSanitizing( $request );
		
		$this->request = $request; 
		$this->template = 'master'; 
		$this->view = empty( $request['view'] ) ? 'displayEntries' : $request['view'] ;
		
		if ( strcasecmp( $_SERVER["QUERY_STRING"], "administration" ) == 0)
		{
			$this->view = "editEntries";
			//$this->action = "login";
		}
		
		$this->action = empty( $request['action'] ) ? null : $request['action'];
		
		if (( !empty( $request['async'] ) &&
			 $request['async'] == "true" ) ||
			 $this->action == "dataRequest")
		{
			$this->isAsyncCall = true;
			$this->template = 'master2';
		}
		
		$this->loginController = new Login( $this );
		$this->model = new Model( $this->getDataDomain() );
		// Writes the page password and site URL to the session if not done already.
		$this->loginController->getAdminPagePassword();
		$this->getSiteUrl();
		$this->getPageUrl();
		$this->getApprovalRequired();
		$this->getNotificationEmail();
		$this->getEntriesCountPerPage();
	}   
	
	/**
	* Displays the content / Processes input
	* 
	* @return String Content. 
	*/
	public function Display()
	{   	
		$status = '';
		$action = $this->action;
		$view = new View();
		$view->SetTemplate( $this->template ); 
		$view->Assign('action', $action);
		$view->Assign('view', $this->view);
		$view->Assign('approvalRequired', $this->getApprovalRequired());
		$view->Assign('dataDomain', $this->getDataDomain());
		$view->Assign('isLoggedIn', $this->loginController->getIsLoggedIn() );
				
		$this->AssignConfigurationValues( $view );

		if( !$this->loginController->DoCheckProceedProcessing() )
		{
			$view->Assign( "statusMessage", "Zugang abgelehnt. Access denied." );
			return $view->LoadTemplate();	
		}
		
		if( isset( $action ))
		{
			switch ( $action )
			{	
				case 'dataRequest':
					$this->view = "dataRequest";
					$this->ProcessDataRequest(
						$view);
					break;
				
				case 'addNewEntry':
					// Workaround for security issue.
					// addNewEntry is the only allowed write action without login.
					// Ensure is set to zero.
					if( array_key_exists("entryId", $this->request ) )
					{
						$this->request['entryId'] = 0;
					}
					// Then do a normal storing.
				case 'storeEntry':
					if( isset( $this->request['entryId'] ) )
						{
							$this->StoreItem(
								$this->request,
								$view,
								$action);
						}
						else 
						{
							echo "No id given";	
						}
					exit();	
					break;
					
				case 'deleteEntry':
					$this->DeleteItem(
						$this->request,
						$view,
						$action);
					break;
					
				case 'approveEntry':
					$this->ApproveItem(
						$this->request,
						$view,
						$action);
					break;
					
				case 'login':
					$this->loginController->LoginUser( 
						$this->request,
						$view);
					exit();
					break;
					
				case 'logout':
					$this->loginController->LogoutUser( 
						$this->request,
						$view);
					break;
				case 'moveUp':
					$this->moveEntry(
						$this->request,
						$view,
						-1);
					break;
				case 'moveDown':
					$this->moveEntry(
						$this->request,
						$view,
						+1);
					break;
			}
		}
		
		switch( $this->view )
		{   				
			case 'entries':
				$this->DisplayEntries(
						$this->request, 
						$view);
				break;
				
			case 'editEntries':
				$this->DisplayEntriesPage(
						$this->request,
						$view,
						true);
				break;
			
			case 'displayEntries':
				$this->DisplayEntriesPage(
						$this->request,
						$view,
						true);
				break;
			
			default:
				break;			
		}
		
		return $view->LoadTemplate();   
	}  
	
	/**
	* Assigns the configuration to the given view
	* 
	* @param View
	*/
	public function AssignConfigurationValues(
		$view)
	{
		$configuration = array();
		
		$configuration['GB_VERSION'] = Configuration::$GB_VERSION;
		$configuration['GB_DATE'] = Configuration::$GB_DATE;
		$configuration['siteUrl'] = $this->getSiteUrl();
			
		$view->Assign( 'Configuration', $configuration );
	}
	
	/**
	* Processes a data request. 
	* Sends only plain data.
	*
	* @param View
	*/
	public function ProcessDataRequest(
		$view)
	{
		$entry = null;
		$entryId = 0;
		$content = "";
		
		$entry= $this->tryLoadEntryFromRequest();
		
		if( $entry!= null && 
			$entry->getId() != 0)
		{
			$text = html_entity_decode( $entry->getText() );
			$text = preg_replace('#<br\s*/?>#i', "\n", $text); 			
			$content = $entry->getName() . ";;;" . $entry->getEmail() . ";;;" . $entry->getHomepage() . ";;;" . $text . ";;;" . $entry->getIp(); 
		}
		else 
		{
			$content = "Entry with ID " . $entryId . " does not exist.";
		}
											   				
		$view->Assign( "content", $content );
	}
	
	/**
	* Displays the entrypage
	* 
	* @param Array
	* @param View
	* @param Bool Edit mode
	*/
	public function DisplayEntriesPage(
		$request,
		$view,
		$editMode)
	{ 
		$entries = $this->model->GetAllEntries();
		
		$isLoggedIn = $this->loginController->getIsLoggedIn();
		
		$viewEntriesTable = new View();
		$viewEntriesTable->SetTemplate('page_display');
		
		$this->AssignConfigurationValues( $viewEntriesTable );
		
		$viewEntriesTable->Assign('entries', $entries);
		$viewEntriesTable->Assign('startAt', $this->tryLoadStartAtFromRequest());
		$viewEntriesTable->Assign('showEntriesCount', $this->getEntriesCountPerPage());
		$viewEntriesTable->Assign('isEditMode', $editMode);
		$viewEntriesTable->Assign('isLoggedIn', $isLoggedIn);
		$viewEntriesTable->Assign('dataDomain', $this->getDataDomain());
		$viewEntriesTable->Assign('approvalRequired', $this->getApprovalRequired());
		$viewEntriesTable->Assign('action', $this->action);
		$viewEntriesTable->Assign('view', $this->view);
		   		
		$view->Assign('content', $viewEntriesTable->LoadTemplate());  									   
		$view->Assign('entries', $entries);
		$view->Assign('dataDomain', $this->getDataDomain());
	}
	
	/**
	* Displays the entries only
	* 
	* @param Array
	* @param View
	* @param Bool Edit mode
	*/
	public function DisplayEntries(
		$request,
		$view)
	{ 
		$entries = $this->model->GetAllEntries();
		
		$isLoggedIn = $this->loginController->getIsLoggedIn();
				
		$viewEntries = new View();
		$viewEntries->SetTemplate('entries');
				
		$viewEntries->Assign('entries', $entries);
		$viewEntries->Assign('isEditMode', $isLoggedIn);
		$viewEntries->Assign('isLoggedIn', $isLoggedIn);
		$viewEntries->Assign('showEntriesCount', $this->getEntriesCountPerPage());
		$viewEntries->Assign('startAt', $this->tryLoadStartAtFromRequest());
		   		
		$view->Assign('content', $viewEntries->LoadTemplate());  									   
		$view->Assign('entries', $entries);
		$view->Assign('dataDomain', $this->getDataDomain());
	}
		
	/**
	* Stores the item from request.
	*
	* @param Array
	* @param View
	*/
	public function StoreItem( 
		 $request,
		 $view,
		 $action)
	{
		$id = $this->doStoreEntry( $request, $view);
				
		if( $id != null &&
		   $id > 0 )
		{
			//$status_ = "Der Datensatz wurde erfolgreich gespeichert.";
			$status_ = "";
			echo $id;	
		}				
		else 
		{
			$status_ = "Fehler beim Speichern. Bitte versuchen Sie es erneut.";
		}
		
		$status  = $view->GetValue( 'statusMessage' );

		if ( !empty( $status ) )
		{
			$status .= '<br/>';
		}
		
		$status .= $status_;
		$view->Assign( "statusMessage", $status );
	}
	
	/**
	* For deleting items.
	*
	* @param Array
	* @param View
	* @param String
	*/
	public function DeleteItem( 
		 $request,
		 $view,
		 $action)
	{
		$status ="";
		if( $action == "deleteEntry" )
		{
			$entry= $this->tryLoadEntryFromRequest();
			if( $entry!= null )
			{
				$deleted = $entry->Delete();
			}
		}
				
		if($deleted)
		{
			if (  isset( $request["otp"]) )
			{
				$status = "Der Eintrag wurde gelöscht.";
				$view->Assign( "statusType", "info" );
			}	
		}				
		else 
		{
			$status = "Fehler beim Löschen des Datensatzes. Bitte versuchen Sie es erneut.";
		}
		
		$view->Assign( "statusMessage", $status );
	}
	
	/**
	* For approving items.
	*
	* @param Array
	* @param View
	* @param String
	*/
	public function ApproveItem( 
		 $request,
		 $view,
		 $action)
	{	
		$entry = $this->tryLoadEntryFromRequest();
		
		if( $entry!= null && 
			$this->IsApprovalKeyValid() )
		{
			$entry->setApproved( true );
			$entry->Store();
			$status = "Der Eintrag wurde freigegeben.";
			$view->Assign( "statusType", "info" );
		}
		else
		{
			$status = "Der angegebene Eintrag existiert nicht oder der Schlüssel ist ungültig.";	
		}
		
		$view->Assign( "statusMessage", $status );
	}
	
	/**
	* Checks if the requests one time pad is valid for changes on the given entry. 
	*/
	public function IsApprovalKeyValid()
	{
		if( !isset( $this->request["entryId"] ) ||
			!isset( $this->request["otp"] ) ||
			!isset( $this->request["action"] ))
		{
				return false;
		}
		
		$entry = $this->tryLoadEntryFromRequest();
		
		if( $entry == null )
		{	
			return false;
		}
				
		$key = $this->doMakeApprovalKey( $entry );
		
		if( strcmp( $this->request["otp"], $key) == 0 )
		{
			return true;
		}
		echo "Direct edit key invalid.";
		return false;		
	}
	
	/**
	* Gets the site url out of the session.
	* If not set tries to get out of the producer generated page that includes the gb. 
	*/
	public function getSiteUrl()
	{		
		global $siteUrl;
		
		if ( isset( $siteUrl ))
		{
			$siteUrl = rtrim( $siteUrl, "/" );
			
			$_SESSION["siteUrl"] = $siteUrl;
			return $siteUrl;
		}
		if ( isset( $_SESSION["siteUrl"] ) )
		{
			return $_SESSION["siteUrl"];
		}
	}
	
	/**
	* Gets the page url out of the session.
	* If not set tries to get out of the producer generated page that includes the gb. 
	*/
	public function getPageUrl()
	{		
		global $pageUrl;
		
		if ( isset( $pageUrl ))
		{
			$pageUrl = rtrim( $pageUrl, "/" );
			
			$_SESSION[$this->getDataDomain() ."_pageUrl"] = $pageUrl;
			return $pageUrl;
		}
		if ( isset( $_SESSION[$this->getDataDomain() ."_pageUrl"] ) )
		{
			return $_SESSION[$this->getDataDomain() ."_pageUrl"];
		}
	}
	
	/**
	* Gets the current data domain.
	* This is the directory within which the data for the current page is stored. 
	*/
	public function getDataDomain()
	{
		global $dataDomainGb;
		
		if ( isset( $dataDomainGb ))
		{
			return $dataDomainGb;
		}
		if ( isset ( $this->request["dataDomain"] ))
		{
			return $this->request["dataDomain"];
		}
	}
	
	public function getEntriesCountPerPage()
	{
		global $entriesCountPerPage;
		
		if ( isset( $entriesCountPerPage ))
		{
			$_SESSION[$this->getDataDomain() ."_entriesCountPerPage"] = $entriesCountPerPage;
			return $entriesCountPerPage;
		}
		if ( isset( $_SESSION[$this->getDataDomain() . "_entriesCountPerPage"] ) )
		{
			return $_SESSION[$this->getDataDomain() ."_entriesCountPerPage"];
		}
		if ( isset ( $this->request["entriesCountPerPage"] ))
		{
			return $this->request["entriesCountPerPage"];
		}
	}
	
	public function getApprovalRequired()
	{
		global $approveEntries;
		
		if( $this->loginController->getIsLoggedIn() )
		{
			return false;
		}
		
		if ( isset( $approveEntries ))
		{
			$_SESSION[$this->getDataDomain() ."_approveEntries"] = $approveEntries;
			return (bool)$approveEntries;
		}
		if ( isset( $_SESSION[$this->getDataDomain() . "_approveEntries"] ) )
		{
			return $_SESSION[$this->getDataDomain() ."_approveEntries"];
		}
		if ( isset ( $this->request["approveEntries"] ))
		{
			return $this->request["approveEntries"];
		}
	}
	
	public function getNotificationEmail()
	{
		global $notificationEmail;
		
		if ( isset( $notificationEmail ))
		{
			$_SESSION[$this->getDataDomain() ."_notificationEmail"] = $notificationEmail;
			return $notificationEmail;
		}
		if ( isset( $_SESSION[$this->getDataDomain() . "_notificationEmail"] ) )
		{
			return $_SESSION[$this->getDataDomain() ."_notificationEmail"];
		}
		if ( isset ( $this->request["notificationEmail"] ))
		{
			return $this->request["notificationEmail"];
		}
	}
	
	public function getAction()
	{
		if( isset( $this->action ))
		{
			return $this->action;
		}
		
		return null;
	}
	
	public function getView()
	{
		if( isset( $this->view ))
		{
			return $this->view;
		}
		
		return null;
	}
	
	public function getScriptAddress()
	{
		return $this->getPageUrl();
	}
	
	public function getApprovalKey( $entry )
	{
		return $this->doMakeApprovalKey( $entry );
	}
	
	/**
	* Does the storing.
	*
	* @param Array Request
	* @param View
	*/
	private function doStoreEntry(
		$request,
		$view)
	{
		$error = "";
		
		if ( !$this->doValidation( $request, $error ))
		{
			echo $error;
			return;
		}
				
		$entry = $this->tryLoadEntryFromRequest();
		
		if( $entry == null )
		{	
			$entry = new Entry( $this->model );
		}
		
		if($entry->getId() == 0)
		{
			$this->model->EnsureEntryOrderPositionsSet();	
			$this->model->ShiftEntryOrderPositionsBy( 1, 1 );
			$entry->setOrderPosition( 1 );
		}	
						
		$entry->setName( $request['Name'] );
		$entry->setEmail( $request['Email'] );
		$entry->setHomepage( $request['Homepage'] );
		$entry->setText( $request['Text'] );
		$entry->setIp( $_SERVER['REMOTE_ADDR'] );
		$entry->setDateCreated( time() );
		
		$entry->setApproved( !$this->getApprovalRequired() );
		
		$id = $entry->Store();		
		
		if ( $this->getApprovalRequired() )
		{
			$mail = new ApprovalEmail($this, $entry);
			$mail->Send();
			$mail = null;
		}
				
		return $id;
	}
	
	private function moveEntry(	
		$request,
		$view,
		$posChange)
	{
		$entry = $this->tryLoadEntryFromRequest();
			
		if( $entry!= null )
		{
			$this->model->MoveEntry( $entry, $posChange );
		}		
	}
	
	private function tryLoadEntryFromRequest()
	{
		$entryId = 0;
		$entry= null;
		
		if( array_key_exists("entryId", $this->request ) )
		{
			$entryId = $this->request['entryId'];
		}
		
		if( is_numeric( $entryId ) && 
			$entryId != 0 )
		{
			$entry = $this->model->GetEntryById( $entryId );
		}
		
		return $entry;
	}
	
	private function tryLoadStartAtFromRequest()
	{
		$startAt = 1;
		if( isset( $this->request["startAt"] ) && 
			is_numeric( $this->request["startAt"] ) &&
			$this->request["startAt"] >= 1)
		{
			$startAt = $this->request["startAt"];
		}
		return $startAt;
	}
	
	private function doValidation( &$request,
								   &$error)
	{
		$arrErr = array();
 	
		if ( !isset($request['Text']) ||
			 empty($request['Text'] ))
		{
			$arrErr[] = "Bitte geben Sie einen Text ein.";	 	
		}
		else
		{
			if ( strlen( $request['Text'] ) > Configuration::$GB_MAXTEXTLENGTH )
			{
				$arrErr[] = "Es sind maximal " . Configuration::$GB_MAXTEXTLENGTH .  " Zeichen erlaubt. Bitte Länge reduzieren.";
			}
			
			$numLines = substr_count( $request['Text'], "&#10;") + 1;
			if( $numLines == 1 )
			{
				$numLines = substr_count( $request['Text'], "<br") + 1;
			}			
			if ( $numLines > Configuration::$GB_MAXTEXTLINES )
			{
				$arrErr[] = "Es sind maximal " . Configuration::$GB_MAXTEXTLINES .  " Zeilen erlaubt. Bitte Zeilenanzahl reduzieren.";
			}
		}
		
		if ( !isset($request['Name']) ||
			 empty($request['Name'] ))
		{
			$arrErr[] = "Bitte geben Sie Ihren Namen ein.";	 	
		}
		
		if ( isset( $request['Email'] ) && strlen( $request['Email'] ) > 0) {			
			if( !preg_match("/^[\w\.\+-_]+@[^.][\w\.-]*\.[\w-]{2,63}$/iu", $request['Email']) ) {
 				$arrErr[] = "Bitte geben Sie eine gültige E-Mail-Adresse an.";
 			}	 	
		}
		
		if ( isset( $request['Homepage'] ) && strlen( $request['Homepage'] ) > 0) {			
			// Add http:// as default protocol (scheme) if the user didn't provide one
			if ( $parts = parse_url($request['Homepage']) ) {
				if ( !isset($parts["scheme"]) ) {
					$request['Homepage'] = "http://" . $request['Homepage'];
				}
			}
			
			/* TODO: if we really want to verify proper domains, find a replacement for below which doesn't verify IDN Domains
			
			if( !filter_var( $request['Homepage'], FILTER_VALIDATE_URL ))
 			{
 				$arrErr[] = "Bitte geben Sie eine gültige URL als Website an.";
 			}
 			*/
		}									
		
		if ( count( $arrErr ) > 0 )
		{
			$error = implode(" ", $arrErr);
			return false;	
		}
		
		return true;
	}
	
	private function doSanitizing( &$request )
	{
		foreach ( $request as $varName => $val )
			{
				$val = filter_var( filter_var( $val,FILTER_SANITIZE_MAGIC_QUOTES ) ,FILTER_SANITIZE_SPECIAL_CHARS );
				$request[$varName] = str_replace( '&#10;', '<br />', $val );
			}
	}
	
	private function doMakeApprovalKey( $entry )
	{
		return md5( $entry->getDateCreated() . $entry->getId() . $this->getDataDomain() );
	}
}
?>
