<?php
$entries = $this->_['entries'];
$isEditMode = $this->_['isEditMode'];
$isLoggedIn = $this->_['isLoggedIn'];
$dataDomain = $this->_['dataDomain'];
$approvalRequired = $this->_['approvalRequired'];
$siteUrl =  $this->_['Configuration']['siteUrl'];
$showEntriesCount = $this->_['showEntriesCount'];
$startAt = $this->_['startAt'];
$view = $this->_['view'];
?>
<?php 
	if ( $view == "editEntries" ) 
	{
?>
	<div id="dialog-confirm-deletion" title="Eintrag löschen" style="display:none;">
		<p>
			<span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 10px 0;"></span>
			<span id="dialog-confirm-deletion-text"></span>
		</p>
	</div>
<?php
	}
?>
	<div id="dialog-edit-entry" title="Eintrag bearbeiten" style="display:none;">
	<?php
	if ( $approvalRequired && !$isLoggedIn)
	{
	?>
	<span><strong>Hinweis: Ihr Eintrag wird vor der Veröffentlichung von uns geprüft.</strong></span>
	<?php
	}
	?>
	<p id="validateTipsEdit"></p>
	<fieldset>
		<label for="zpgbname">Name:</label>
		<input type="text" name="Name" value="Geben Sie Ihren Namen ein" id="zpgbname" class="text ui-widget-content ui-corner-all" style="width:60%; display:block; font-weight: bold; font-size: 1.1em" />
		<label for="zpgbemail">E-Mail:</label>
		<input type="text" name="Email" id="zpgbemail" class="text ui-widget-content ui-corner-all" style="width:60%; display:block; font-weight: bold; font-size: 1.1em" />
		<label for="zpgbhomepage">Website:</label>
		<input type="text" name="Homepage" id="zpgbhomepage" class="text ui-widget-content ui-corner-all" style="width:60%; display:block; font-weight: bold; font-size: 1.1em" />
		<label for="zpgbhomepage">Ihr Kommentar:</label>
		<textarea name="Text" id="zpgbtext" class="text ui-widget-content ui-corner-all" style="width: 98%; height:180px; display:block; font-size: 1.1em"></textarea>
		<?php 
		if ( $isLoggedIn ) 
		{ 
			?>
			<span>IP-Adresse:&nbsp;</span><span id="zpgbip"></span>
			<?php 	
		}
		?>
	</fieldset>
	</div>

	<div style="text-align:left; margin-bottom: 15px;">
	<a id="btnInsertArticle" onclick="javascript:editEntry(0);" href="#">Neuen Eintrag hinzufügen</a>
	</div>

	<div id="entries">
<?php 
		$viewArticles = new View();
		$viewArticles->SetTemplate('entries');
				
		$viewArticles->Assign('entries', $entries);
		$viewArticles->Assign('isEditMode', $isEditMode);
		$viewArticles->Assign('isLoggedIn', $isLoggedIn);
		$viewArticles->Assign('showEntriesCount', $showEntriesCount);
		$viewArticles->Assign('startAt', $startAt);

		echo $viewArticles->LoadTemplate();
?>
</div>

<p></p>
<?php	
if ( $isLoggedIn )
{
?>
	<input type="button" id="btnLogout" onClick="javascript:window.location = '?action=logout'; return false;" value="Abmelden"/>
	<script>
		$( "#btnLogout" ).button();
	</script>
<?php
}
?>