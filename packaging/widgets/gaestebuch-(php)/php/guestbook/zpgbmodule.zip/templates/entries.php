<div style="margin-top: 4px;"></div>
<?php
$entries = $this->_['entries'];
$showEntriesCount = $this->_['showEntriesCount'];
$startAt = $this->_['startAt'];
$isEditMode = $this->_['isEditMode'];
$isLoggedIn = $this->_['isLoggedIn'];
$pageCount = ceil(count($entries) / $showEntriesCount);
$activePage = ceil( $startAt / $showEntriesCount );
$count = 0;
$showCount = 0; 
$mylocale = setlocale(LC_TIME, 'de_DE.utf8', 'de.utf8', 'German_Germany.UTF-8', 'German_Germany.UTF8', 'German_Germany.1252');

if($entries != null)
{
	//print_r($entries);
	foreach($entries as $currEntry) 
	{  
		$count++;
		if ( $showCount + 1 > $showEntriesCount )
		{
			break;
		}
		if ( $count < $startAt )
		{
			continue;
		}
		if ( !$currEntry->getApproved() )
		{
			continue;
		}
				
		if ( $isEditMode && $isLoggedIn)
		{
	?>
		<div class="inline-editing" onClick="javascript:void(0);" ondblclick="javascript:editEntry(<?php echo $currEntry->getId(); ?>,<?php echo $startAt; ?>);">
		<div class="inline-editing-menu-dummy"></div>	
		<div class="inline-editing-menu">
			<a class="inline-editing-edit" href="javascript:void(0);" onClick="javascript:editEntry(<?php echo $currEntry->getId(); ?>, <?php echo $startAt; ?>); return false;" title="Bearbeiten">Bearbeiten</a>
			<a class="inline-editing-delete" href="<?php echo 'javascript:deleteEntry(' . $currEntry->getId() . ',\'' . $currEntry->getName() . '\',' . $startAt . ')'; ?>" title="Löschen">Löschen</a>
			<a class="inline-editing-up-active" href="javascript:void(0);" onClick="javascript:updateEntriesAsync('<?php echo 'action=moveUp&entryId=' . $currEntry->getId() . '&startAt=' . $startAt; ?>'); return false;" title="Nach oben verschieben">Nach oben verschieben</a>
			<a class="inline-editing-down-active"  href="javascript:void(0);" onClick="javascript:updateEntriesAsync('<?php echo 'action=moveDown&entryId=' . $currEntry->getId() . '&startAt=' . $startAt; ?>'); return false;" title="Nach unten verschieben">Nach unten verschieben</a>
		</div> 
	<?php
		} 
	?>
		<div class="zpgb-entry" style="position:relative; padding-bottom:15px;">
		<?php //echo $currEntry->getOrderPosition(); ?>
		
		<?php 
		  $date = strftime('%d.%m.%Y %H:%M', $currEntry->getDateCreated()); 
		  if ( strpos($mylocale, '1252') ){ 
		    // we run on a windows system without UTF8 locale, so we need to convert the output string to UTF8 manually
		    $date = iconv('WINDOWS-1252', 'UTF-8', $date);
		  }
		?>
		
		<?php $email = $currEntry->getEmail();   ?>
		<?php $homepage = $currEntry->getHomepage();   ?>
		<?php $name = $currEntry->getName();   ?>	
			<div style="padding-top:3px; border-top:1px #e0e0e0 solid;">	
			<div style="display:inline-block;"><b><?php if ( !empty($homepage) ) { echo "<a href=\"" . $homepage . "\" target=\"_blank\">"; } ?><?php echo $name; ?><?php if ( !empty($homepage) ) { echo "</a>"; } ?></b></div>
			<div style="display:inline-block; position:absolute; right:0;"><?php echo $date; ?></div>
			</div>
			<div>
			<p><?php echo $currEntry->getText(); ?></p>
			</div>
		</div>
	<?php
		if ( $isEditMode && $isLoggedIn)
		{ 	
	?>
			</div>
	<?php
		}
		$showCount++;
	}
	if ( $pageCount > 1 )
	{
		?>
		<div style="text-align:right;">
		<?php
		for ($page = 1; $page <= $pageCount; $page++) 
		{
			$currStart = ($page * $showEntriesCount) - $showEntriesCount + 1;
			
			if( $page >= 2 ) { echo "&#124;"; }
			
			if( $page == $activePage )
			{
				?> 
				<b><?php echo $page ?></b>
				<?php 	
			}
			else
			{
				?>
				<a href="javascript:void(0)" onclick="updateEntriesAsync('entriesCountPerPage=<?php echo $showEntriesCount; ?>&startAt=<?php echo $currStart ?>')"><?php echo $page ?></a>
				<?php 
			}
		}
		?>
		</div>
		<?php  
	}
}
else 
{
	echo '<p>Noch keine Einträge vorhanden.</p>';
}
?>