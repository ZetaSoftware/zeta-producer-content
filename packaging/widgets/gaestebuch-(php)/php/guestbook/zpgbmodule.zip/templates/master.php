<?php
$isLoggedIn = $this->_['isLoggedIn'];
$view = $this->_['view'];
$action = $this->_['action'];
$dataDomain = $this->_['dataDomain'];
$approvalRequired = $this->_['approvalRequired'];
$inlineEditingIncludePath =  dirname( __FILE__ ) . "/../etc/_inline-editing/";
$inlineEditingIncludeUrl = $this->_['Configuration']['siteUrl'] . "/assets/php/guestbook/etc/_inline-editing/" ;

if ( true )
{
	include $inlineEditingIncludePath . "inline-editing.css";
?>
	
	<script type="text/javascript">
	  // inject jQuery-UI stylesheet
  	var script  = document.createElement('link');
    script.href = "<?php echo $this->_['Configuration']['siteUrl']?>/assets/php/guestbook/etc/jquery/theme/jquery-ui-1.8.11.custom.css";
    script.type = "text/css";
    script.rel  = "Stylesheet";
    var head    = document.getElementsByTagName('head')[0];
    head.appendChild(script);
    
    // only load jQuery if it isn't already being loaded
  	if (typeof jQuery === "undefined"){ 
      var script  = document.createElement('script');
      script.src  = "<?php echo $this->_['Configuration']['siteUrl']?>/assets/php/guestbook/etc/jquery/jquery-1.5.1.min.js";
      script.type = "text/javascript";
      var head    = document.getElementsByTagName('head')[0];
      head.appendChild(script);
  	};
	</script>
	<script type="text/javascript" src="<?php echo $this->_['Configuration']['siteUrl']?>/assets/php/guestbook/etc/jquery/jquery-ui-1.8.11.custom.min.js"></script>


	<script type="text/javascript">
		<?php
		include dirname( __FILE__ ) . "/../etc/zpguestbook.js";
		?>
	</script>
	
	<script type="text/javascript">
	<!--
		$(function() {
		
			<?php 
			if ( !$isLoggedIn && $view == "editEntries")
			{
			?>
			InitGuestbook( "<?php echo( $dataDomain ); ?>", "<?php echo( session_id() ); ?>", true );
			<?php
			}
			else 
			{
			?>
			InitGuestbook( "<?php echo( $dataDomain ); ?>", "<?php echo( session_id() ); ?>", false );
			<?php 
			} 
			?>
		});
	//-->
	</script>
	<style type="text/css" >
		input.text { margin-bottom:5px; padding: .4em; }
		fieldset { padding:0; border:0; margin-top:5px; }
		validateTips { border: 1px solid transparent; padding: 0.3em; }
		.ui-dialog .ui-state-error { padding: .3em; }
	</style>
	<div id="login-form" title="Anmelden" style="display:none;">
		<p id="validateTips">Um in den Administrationsmodus zu wechseln, melden Sie sich bitte an.</p>
		<div id="login-input-area"><fieldset>
			<label for="password">Kennwort:</label>
			<input type="password" name="password" id="password" value="" class="text ui-widget-content ui-corner-all" style="width:auto;" />
		</fieldset>
		</div>
	</div>
<?php 	
}
?>


<form name="masterForm" id="masterForm" action="?" method="post">
<input type="hidden" name="view"/>
<input type="hidden" name="action"/>

<script type="text/javascript"> 
<!--
var theForm = document.forms['masterForm'];
if (!theForm) {
    theForm = document.masterForm;
}
function __doPostBack(view, action) 
{
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) 
        {
    	theForm.view.value = view;
        theForm.action.value = action;
        theForm.submit();
    }
}
-->
</script>

<?php
	if(	isset($this->_['statusMessage']) &&
	   	!empty($this->_['statusMessage']))
	{
		$styleType = "ui-state-error";
		
		if(	isset($this->_['statusType']) &&
	   		!empty($this->_['statusType']))
		{
			switch ($this->_['statusType']) 
			{
				case "warning":
					$styleType = "ui-state-highlight";
					break;
				case "info":
					$styleType = "ui-state-highlight";
					break;
				
				default:
					$styleType = "ui-state-error";
					break;
			}
		}	
?>
		<div class="<?php echo $styleType; ?> ui-corner-all" style="margin-bottom:10px; padding:4px;">
			<?php echo $this->_['statusMessage']; ?>
		</div>
<?php
	} 
?>

<?php
	if(isset($this->_['content']))
	{
		echo '<div class="zpgbwrapper" id="guestbook_content">';
		
		echo $this->_['content'];
		
		echo '</div>';
	} 
?>
</form>