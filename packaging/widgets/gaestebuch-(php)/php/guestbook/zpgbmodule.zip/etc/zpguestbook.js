/*
 * Zeta Producer Guestbook
 * http://www.zetaproducer.com
 * 
 * @author  Daniel Friedrich
 * @version 1.0 29.11.2011
 * @copyright (c)2011 zeta Software GmbH
*/

var _dataDomain = null;
var _sessionId = null;
var _currentEntryId = null;

function InitGuestbook( dataDomain,  
				  sessionId,
				  showLoginDialog)
{
	_dataDomain = dataDomain;
	_sessionId = sessionId;
	
	if ( showLoginDialog )
	{
		OpenLoginDialog();		
	}
}
					
function OpenLoginDialog()
{
	$( "#login-form" ).dialog( "open" );
}

$( function() 
{
	var pagePassword = $( "#password" );
	var	tips = $( "#validateTips" );

	function loginError( t ) 
	{
		tips.text( t );
		tips.addClass( "ui-state-highlight" );
		pagePassword.addClass( "ui-state-error" );
		setTimeout(function() 
		{
			tips.removeClass( "ui-state-highlight", 1500 );
		}, 500 );
	}
	
	$( "#login-form" ).dialog({
		autoOpen: false,
		height: 200,
		width: 280,
		modal: true,
		hide: "fade",
		show: "fade",
		buttons: {
			"Anmelden": function() {
				pagePassword.removeClass( "ui-state-error" );
			
				$.get("<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/guestbook/gb.main.php",
						{
							view: "editEntries",
							action: "login",
							password: pagePassword.val(),
							dataDomain: _dataDomain,
							PHPSESSID: _sessionId
						},
						function(data)
						{
							if ( data == "ok" ) 
							{
								$( "#login-input-area" ).fadeOut();
								setTimeout(function() 
								{
									tips.text( "Administrationsumgebung wird geladen..." );
								}, 500 )
										
								$.get("<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/guestbook/gb.main.php",
									{
										view: "editEntries",
										dataDomain: _dataDomain,
										async: "true",
										PHPSESSID: _sessionId
									},
									function(data)
									{
										setTimeout(function() 
										{
											$( "#guestbook_content" ).html( data ).fadeTo();
											$( "#login-form" ).dialog( "close" );
										}, 2000 )
									}
								);													
							}
							else
							{
								loginError( data );
							}
						}
					);
			},
			"Abbrechen": function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
			tips.text( "Um in den Administrationsmodus zu wechseln, melden Sie sich bitte an." );
			$( "#login-input-area" ).fadeIn();
			pagePassword.val( "" ).removeClass( "ui-state-error" );
		}
	});

	$('#login-form').live('keyup', function(e){   if (e.keyCode == 13) {     $(':button:contains("Anmelden")').click();   } }); 
		
});

function reportEditEntryError( t ) 
{
	$( "#validateTipsEdit" ).text( t );
	$( "#validateTipsEdit" ).addClass( "ui-state-highlight" );
	$( "#validateTipsEdit" ).show();
	
	setTimeout(function() 
	{
		$( "#validateTipsEdit" ).removeClass( "ui-state-highlight", 1500 );
	}, 500 );
	setTimeout(function() 
	{
		$( "#validateTipsEdit" ).fadeOut();
	}, 5000 );
}

function retrieveDataAsync( entryId, callback )
{				
	$.get("<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/guestbook/gb.main.php",
			{
				view: "dataRequest",
				action: "dataRequest",
				entryId: entryId,
				dataDomain: _dataDomain,
				async: "true",
				PHPSESSID: _sessionId
			},
			function(data)
			{	
				callback( data );
			}
	);
} 

function retrieveDataSync( entryId )
{
	 var result = null;      
	 var scriptUrl = "<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/guestbook/gb.main.php";      
	 $.ajax(
	 {
		 url: scriptUrl,
		 type: 'get',
		 dataType: 'html',
		 async: false,
		 data:
		 {
			view: "dataRequest",
			action: "dataRequest",
			entryId: entryId,
			dataDomain: _dataDomain,
			async: "true",
			PHPSESSID: _sessionId
		 },
		 success: function(data) 
		 {
			 result = data;
		 }
	 });
	 
	 return result;
}

function setEntryData( entryData )
{
	var arrData = entryData.split(";;;");
	var name = $( "#zpgbname" );
	var email = $( "#zpgbemail" );
	var homepage = $( "#zpgbhomepage" );
	var text = $( "#zpgbtext" );
	var ip = $( "#zpgbip" );
	
	if( arrData.length <= 1  )
	{
		alert("Fehler bei der Datenübertragung.\n" + entryData);
		return;
	}

	name.val( arrData[0] );
	email.val( arrData[1] );
	homepage.val( arrData[2] );
	text.val( arrData[3] );
	ip.html( arrData[4] );
}

function editEntry(entryId, startAt)
{
	var name = "";
	var email = "";
	var homepage = "";
	var text = "";
	
	if( entryId != 0 )
	{
		retrieveDataAsync( entryId, setEntryData  );	
	}
	
	_currentEntryId = entryId;

	showEditEntryDialog( entryId, name, email, homepage ,text, startAt);
}

function storeEntry( entryId, 
					   sName,
					   sEmail,
					   sHomepage,
					   sText )
{
	var result = null;      
	var scriptUrl = "<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/guestbook/gb.main.php";
	
	 $.ajax(
	 {
		 url: scriptUrl,
		 type: 'post',
		 dataType: 'html',
		 async: false,
		 data:
		 {
			view: "dataRequest",
			action: ( entryId ) > 0 ? "storeEntry" : "addNewEntry",
			async: "true",
			entryId: entryId,
			Name: sName,
			Email: sEmail,
			Homepage: sHomepage,
			Text: sText,
			dataDomain: _dataDomain,
			PHPSESSID: _sessionId
		 },
		 success: function(data) 
		 {
			 result = data;
		 }
	 });
	 
	 return result;
}

function updateContentAsync( request )
{
	$( "#guestbook_content" ).load( "<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/guestbook/gb.main.php?async=true&dataDomain="  + _dataDomain + "&PHPSESSID=" + _sessionId + "&" + request );
}

function updateEntriesAsync( request )
{
	$( "#entries" ).load( "<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/guestbook/gb.main.php?view=entries&async=true&dataDomain=" + _dataDomain + "&PHPSESSID=" + _sessionId + "&" + request);
}

function showEditEntryDialog( 
		entryId,  
		sName, 
		sEmail, 
		sHomepage, 
		sText,
		startAt)
{		
	var name = $( "#zpgbname" );
	var email = $( "#zpgbemail" );
	var homepage = $( "#zpgbhomepage" );
	var text = $( "#zpgbtext" );
	var	tips = $( "#validateTipsEdit" );
	
	name.val( sName );	
	text.html( sText );
													
	$( "#dialog-edit-entry" ).dialog(
	{
		autoOpen: true,
		resizable: false,
		height: 510,
		width: 550,
		modal: true,
		hide: "fade",
		show: "fade",
		buttons: {
			"OK": function() {
				var errorState = false;
				text.removeClass( "ui-state-error" );
				name.removeClass( "ui-state-error" );

				if( text.val().length == 0)
				{
					text.addClass( "ui-state-error" );
					reportEditEntryError ( "Bitte geben Sie einen Text ein." );
					errorState = true;
					text.focus();
				}
				
				if( name.val().length == 0 || 
					name.val() == "Geben Sie Ihren Namen ein")
				{
					name.addClass( "ui-state-error" );
					reportEditEntryError ( "Geben Sie Ihren Namen ein." );
					errorState = true;
					name.focus();
				}
				
				if( errorState )
				{
					return;
				}

				tips.text( "Eintrag wird gespeichert..." );

				data = storeEntry( _currentEntryId, 
									 name.val(),
									 email.val(),
									 homepage.val(),
									 text.val() );

				if ( is_int( data ) && 
					 data > 0) 
				{			
					$.get("<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/guestbook/gb.main.php",
						{
							view: "entries",
							startAt: startAt,
							dataDomain: _dataDomain,
							async: "true",
							PHPSESSID: _sessionId
						},
						function(data)
						{		
							$( "#entries" ).html( data ).fadeTo();
						
							setTimeout( function() 
							{
								$( "#dialog-edit-entry" ).dialog( "close" );
								tips.text( "" );
							}, 500 );	
						}
					);													
				}
				else
				{
					reportEditEntryError( data );
				}
			},
			"Abbrechen": function() {
				$( this ).dialog( "close" );
			}
		},
		open: function()
		{
			tips.hide();
			window.onbeforeunload = function(){ return 'Wenn Sie diese Seite verlassen, gehen die aktuellen Änderungen verloren.\nSind Sie sicher?'; }
			name.css('color', '#000000');
								
			name.focus( function() 
			{				
		        if(this.value == this.defaultValue) 
			    {
		            this.value = "";
		            $(this).css('color', '#000000');

			    } 
		    }); 
			
			name.blur( function() 
			{
		        if( this.value == "")
		        {
		            this.value = this.defaultValue;
		            $(this).css('color', '#666');
		        }
		    }); 
		},
		close: function() 
		{
			window.onbeforeunload = null;
			name.val( "" );
			text.val( "");
			homepage.val( "" );
			email.val ( "" );
		}
	});
}

function deleteEntry( id, name, start )
{
	document.getElementById('dialog-confirm-deletion-text').innerHTML = "Wollen Sie den Eintrag von \"" + name + "\" wirklich löschen?";
	
	$( "#dialog-confirm-deletion" ).dialog( "destroy" );
	
	$(function() {
		$( "#dialog-confirm-deletion" ).dialog({
			resizable: false,
			height:180,
			width:300,
			modal: true,
			hide: "fade",
			show: "fade",
			buttons: {
				"OK": function() {
					$( this ).dialog( "close" );
					
					updateEntriesAsync("action=deleteEntry&entryId=" + id + "&startAt=" + start);
				},
				"Abbrechen": function() {
					$( this ).dialog( "close" );
				}
			}
		});
	});
}

function is_int(value){ 
	  if((parseFloat(value) == parseInt(value)) && !isNaN(value)){
	       return true;
	   } else { 
	      return false;
	   } 
	}